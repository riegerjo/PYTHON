name = input('What\'s your name?')
print('Hello {} !'.format(name))
