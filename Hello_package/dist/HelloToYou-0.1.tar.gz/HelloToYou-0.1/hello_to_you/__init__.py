print('Welcome to CodingWaves!')
